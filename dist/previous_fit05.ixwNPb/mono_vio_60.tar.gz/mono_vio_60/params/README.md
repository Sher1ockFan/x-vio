# 参数文件更换说明

Mac 源工程：`~/Documents/vio_ws/mono_vio_60/params/`。安装包解压到 `~/Documents/mono_vio_60` 后，Jetson 使用 `~/Documents/mono_vio_60/params/`。程序读取的是运行所在机器上的文件，修改 Mac 文件不会自动更新 Jetson。

## 当前已填写的内容

已按用户确认，临时沿用旧 `fit_05` 的全套参数，活动配置标记为 `borrowed_fit05_trial_unvalidated`，可以进行新相机流程试跑：

- `orb_trial.yaml`：原样复制 `Camera.type`、八个 `Camera1.*` 内参/畸变数值、`IMU.T_b_c1` 及 IMU 噪声/随机游走/500 Hz 配置。
- `timing.json`：沿用 +0.016881056522098987 秒（16881057 ns）残余时偏，不复用旧录制的时钟锚点或拟合系数。
- `camera_profile.json`：仍使用新接口 `/dev/video0`、`vi-output, jl_gmsl 10-003a`、1920×1536 UYVY、零裁剪及 60 fps 请求；时间域暂沿用 `cntvct` 假设，尚未验证新驱动时钟。

旧参数原件保存在 `legacy_fit05/`。`provenance/borrowed_intrinsics.json` 记录较早的仅内参复制操作；`provenance/borrowed_fit05_trial.json` 记录此次全套临时借用。

旧参数对应 1920×1440，新配置候选输入是 1920×1536；没有证据证明两幅图像是按比例缩放得到的，所以本次没有按高度比例改 fy/cy，也没有再做主点偏移。当前原生 ORB 会按 960×768 的处理尺寸自动将 fx/fy/cx/cy 缩半，畸变系数不变；不要在文件里再手工缩半。源 ORB 参数已有旧工程的半尺寸主点约定，本次没有重复补偿。

**临时可启动不等于新相机标定准确。** 数值、尺寸、时偏和指纹检查仍执行；新相机的内参、装配外参、时间域及时间偏移均尚未实测验证。

## 后续更换哪些文件

| 活动文件 | 修改内容 | 说明 |
| --- | --- | --- |
| `orb_trial.yaml` | `Camera.type`；`Camera1.fx/fy/cx/cy`；`Camera1.k1/k2/k3/k4` | 新鱼眼内参与畸变，填写对应输入图像坐标系的值 |
| 同一个 `orb_trial.yaml` | `IMU.T_b_c1`；`IMU.NoiseGyro/NoiseAcc/GyroWalk/AccWalk/Frequency` | 相机→IMU 的 4×4 外参、IMU 噪声和频率；当前解析器对应 500 Hz |
| `timing.json` | `timeshift_cam_imu_seconds`、`timeshift_cam_imu_rounded_ns` 及映射/指纹字段 | 活动文件已临时采用旧 +16.881 ms；新标定完成后替换为新测时偏 |
| `camera_profile.json` | `device`、`expected_card`、`raw_width/raw_height`、`crop_top/crop_bottom`、`requested_fps`、`timestamp_domain` 等 | 设备接口及图像布局；当前默认 video0、1920×1536 UYVY、零裁剪、请求 60 fps，尚未实测 |

`orb_trial.yaml` 中 `Camera.width/height` 必须等于裁剪后输入尺寸，`Camera.fps` 必须与 `requested_fps` 一致。`Camera.newWidth/newHeight` 是 ORB 内部处理尺寸，不是驱动原始输出尺寸。

新标定及独立复验完成后，将 `Camera.calibrationStatus` 和 `timing.json` 的 `calibration_status` 同步设为 `validated`；临时借用期间保留 `borrowed_fit05_trial_unvalidated`，不要仅为了启动就伪改状态。保留 `%YAML:1.0` 与带引号的 `File.version: "1.0"`。不要把 Kalibr 的 `camera.yaml` 或 `cam_imu.yaml` 直接改名当成 ORB 配置，它们的字段格式和外参方向不同。若 Kalibr 提供 `T_cam_imu`（IMU→相机），ORB 的 `IMU.T_b_c1`（相机→IMU）使用其逆矩阵，平移单位为米。

`timing.json` 中的两个时偏字段应满足 `rounded_ns = round(seconds × 1e9)`；程序使用 `图像在 IMU 时间基准上的时间 = 相机映射到 RAW 后的时间 + 时偏`，只加一次。秒与纳秒不要混用。

## 更换顺序

1. 停止当前 VIO，在 Jetson 的活动 `params/` 目录修改上述文件。若要保留 Mac 编译包同步更新，也修改 Mac 对应目录。
2. 核对图像尺寸、裁剪、帧率及时间域。正式采用前验证 `timestamp_domain` 实际为 `cntvct`、`monotonic` 或 `raw`；当前 `cntvct` 只是临时沿用的假设；`camera_id`/`rig_id` 替换成当前相机和装配的稳定身份。
3. 若更改了相机配置，运行下面的只读命令取得 `camera_profile_sha256`，填入 `timing.json`。临时借用时保留 `borrowed_fit05_trial_unvalidated`；只有整套新参数验证后才使用 `validated`。更新指纹不会使暂借参数自动变准确。
4. 重启后新运行会保存参数快照。不要改历史 `runs/` 或录制目录里的 `settings.yaml`、`timing.json`、`camera_profile.json`；它们记录当时的参数，回放使用这些快照。

Jetson 解压包中：

```bash
kit="$HOME/Documents/mono_vio_60"
bash "$kit/start.sh" profile
```

Mac 源工程中：

```bash
cd "$HOME/Documents/vio_ws/mono_vio_60"
python3 jetson/camera_config.py describe params/camera_profile.json
```

这些命令只读配置，不打开相机或串口。指纹绑定相机/装配身份、驱动身份、尺寸、裁剪、帧率、像素格式和时钟域，不绑定设备节点路径；只更新字符串或指纹不等于做过测量。

仅修改参数通常不需要重新编译 C++。Mac 参数改好后要更新安装包，可重新运行 `build.sh` 使用现有缓存打包；已部署的 Jetson 可直接替换对应活动参数文件。参考地图绑定使用时的参数和状态。临时配置默认使用 `maps/workspace_trial.osa`，正式配置使用 `maps/workspace_v2.osa`；参数变化后可能被拒绝加载，应使用匹配的新地图，不能编辑地图校验信息绕过检查。

若启动环境设置了 `VIO_SETTINGS`、`VIO_TIMING_FILE` 或 `VIO_CAMERA_PROFILE`，程序读取变量指定的位置；此时不要只修改默认 `params/`。可通过 `printenv VIO_SETTINGS VIO_TIMING_FILE VIO_CAMERA_PROFILE` 查看覆盖路径；没有输出表示未设置这些变量。

`legacy_fit05/`、`orb_trial.template.yaml`、`timing.template.json` 和候选 `camera_video0.json/camera_video1.json` 不会代替活动文件自动生效。`check.sh` 校验程序与只读模板；活动配置在启动时另做数值、尺寸、时偏及指纹一致性检查。

## 启动提示 Missing new-camera calibration

这类提示来自参数预检。此次安装包已包含完整的临时参数；若仍提示缺项，先确认已替换新安装包，以及环境变量是否指向旧的或未填写的配置。启动器会列出缺少的文件、字段及实际路径。无需把临时状态改成 `validated`。

可在 Jetson 执行以下只读核对，不打开相机或串口：

```bash
kit="$HOME/Documents/mono_vio_60"
python3 "$kit/camera_config.py" validate \
  "${VIO_CAMERA_PROFILE:-$kit/params/camera_profile.json}" \
  "${VIO_SETTINGS:-$kit/params/orb_trial.yaml}" \
  "${VIO_TIMING_FILE:-$kit/params/timing.json}"
```

以上核对通过只说明配置完整且一致；不替代新硬件的实际标定和精度复验。
