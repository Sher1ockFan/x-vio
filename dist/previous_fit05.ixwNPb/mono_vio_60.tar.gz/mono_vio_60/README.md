# mono_vio_60：Jetson 使用说明

默认相机为用户选定的 `/dev/video0`（isx031-m3a），目标请求 60 fps。当前未在新 Jetson 部署或采集；当前已按用户要求临时借用 fit_05 全套内外参、IMU 参数和时偏，可按以下步骤在设备上试跑。请求帧率不表示实际采集或 VIO 处理已达到 60 fps。

## 安装与检查

将 `mono_vio_60.tar.gz` 放到 Jetson 家目录，解压到独立目录：

```bash
mkdir -p "$HOME/Documents"
tar -xzf "$HOME/mono_vio_60.tar.gz" -C "$HOME/Documents"
kit="$HOME/Documents/mono_vio_60"
bash "$kit/check.sh"
```

宿主机须为 Ubuntu 22.04 ARM64 / Jetson Linux R36.5，并满足剩余系统图形库和 `python3-numpy` 依赖。本副本使用 OpenCV 4.5.4 编译；所需 OpenCV 4.5、Boost serialization、GLU 运行库及许可证随包放在私有目录。动态链接是否完整以 `check.sh` 为准，不修改宿主机 OpenCV。软件检查成功不证明采集或标定有效。`live-headless` 不创建窗口、不要求 DISPLAY，但当前程序仍链接图形运行库。

## 相机与新标定

```bash
kit="$HOME/Documents/mono_vio_60"
bash "$kit/start.sh" profile
# 自定义配置时使用绝对路径
export VIO_CAMERA_PROFILE="$kit/params/camera_profile.json"
```

默认 `params/camera_profile.json` 来自 video0 候选。`profile` 只读取配置并输出指纹，不打开设备。1920×1536 UYVY、零裁剪、请求 60 fps 来自设备树，尚需实际出帧确认；不能沿用旧机“删第一行”的规则。`camera_video1.json` 仅作备选，不能不重新标定就切换到另一相机。

三个活动文件已配置：

- `params/orb_trial.yaml`：旧 fit_05 的相机模型、八个内参/畸变数值、相机→IMU 外参、IMU 噪声和 500 Hz 配置；输入尺寸为新接口的 1920×1536，ORB 内部处理尺寸为 960×768。
- `params/timing.json`：旧残余时偏 +0.016881056522098987 秒（16881057 ns），在相机映射到 RAW 后只加一次。
- `params/camera_profile.json`：`/dev/video0`、相机身份、图像布局与 60 fps 请求；时间域暂按旧机 `cntvct` 假设处理，尚未验证新驱动是否使用相同时间域。

全套临时参数标记为 `borrowed_fit05_trial_unvalidated`。启动前会显示 `Trial calibration:` 提示，不要求把状态伪改成 `validated`。本次时钟映射仍重新估计，不使用旧录制的时钟锚点。旧镜头内参与旧装配外参可能不适合新硬件，试跑成功不表示初始化或精度有保证。

后续完成新标定时更换活动文件，字段及顺序见安装包 `params/README.md`（源码见 [参数说明](../params/README.md)）。文件在其他位置时可指定绝对路径：

```bash
export VIO_SETTINGS="/绝对路径/参数/orb_trial.yaml"
export VIO_TIMING_FILE="/绝对路径/参数/timing.json"
```

`bash "$kit/check.sh" --devices` 只检查节点与权限，不测试相机出帧或 IMU 通信。

IMU 入口仍使用原 CP2102 的 `/dev/serial/by-id` 路径、FORSENSE 协议和 921600 波特率，原配置为 500 Hz。新机出现 `/dev/ttyUSB0` 只证明适配器被识别；上述路径、实际设备、数据协议与频率仍需确认。

## 实时、录制与回放

以下命令会打开相机和串口；目前使用旧参数进行流程试跑，不能据此验收新硬件的轨迹精度。实时可选原生双窗口或无窗口；省略秒数或传入 `0` 会持续到 Ctrl+C。

```bash
DISPLAY=:0 bash "$kit/start.sh" live
bash "$kit/start.sh" live-headless

# 每次录制指定新的目录，两个命令任选其一
bash "$kit/start.sh" record "$kit/runs/take_01"
DISPLAY=:0 bash "$kit/start.sh" record-view "$kit/runs/take_02"

# 对已正常封存的数据回放或导出
DISPLAY=:0 bash "$kit/start.sh" replay "$kit/runs/take_01"
bash "$kit/start.sh" trajectory "$kit/runs/take_01"
```

按一次 Ctrl+C 后等待收尾。录制 `capture.json` 的 `COMPLETE` 代表封存完成；异常录制可用 `recover TAKE` 检查。每次运行/录制保存相机配置、标定及时间文件快照，回放和导出使用对应快照。继承的旧录制若缺少新快照，不能直接当作新包输入。

`live` / `live-headless` 打印 `LIVE...` 后终端静默；启动错误给出分类原因和日志路径，运行详情写入 `session/console.log`、`session/live.json` 及诊断 CSV。频率与延迟分析保留在 `performance.txt`；实测采集频率、ORB 处理频率和延迟应分别查看。

## 状态与地图

另一个终端可主动查询，不打开传感器、不停止实时运行：

```bash
bash "$kit/start.sh" status
bash "$kit/start.sh" status --watch
bash "$kit/start.sh" status --json
```

状态核对进程身份、数据新鲜度和最新有效帧。`ready` / `stable_ready` 是运行状态，不是精度验收；查询退出码 0 也不表示 VIO 已就绪。

实时默认 `VIO_MAP_MODE=auto`。临时借用配置的参考路径为 `$kit/maps/workspace_trial.osa`；完成新标定后的正式配置默认使用 `$kit/maps/workspace_v2.osa`。`new` 使用未占用的新参考路径，`off` 关闭复用和持久化；`VIO_MAP_FILE` 可指定路径。录制/回放与日常实时参考图隔离。地图仍为 `MONO_IMU_ATLAS_2` 格式，并绑定相机配置及标定状态；旧相机地图不能视为新标定兼容。不要通过更改指纹强行复用不匹配的地图。

地图加载成功后仍须视觉重定位与惯性恢复。恢复保留至少 1.2 秒拟合与 0.6 秒后续独立复验；健康检查与输出有效性策略未修改。正常结束、成熟地图及诊断检查通过后才首次发布参考图，已有参考图不自动覆盖。`session/map_save.json`、`map_session.json`、`recovery_events.csv`、`recovery_timing.csv` 和 `state_diagnostics.csv` 记录结果；保存成功不代表精度通过。

继承的 Shutdown 段错误问题尚未解决。出现非正常退出时应保留日志和返回码，不将其视为正常封存或已修复。

活动配置 `camera_profile.json`、`orb_trial.yaml`、`timing.json` 可随本次标定更新；`check.sh` 检查程序和只读模板的校验和，启动时另行检查活动配置的尺寸、时偏与绑定指纹。原始安装包完整性可通过外部 `.sha256` 文件核对。
