# mono_vio_60

面向新 Jetson Orin NX / `jl_gmsl` 相机的单目＋IMU VIO 独立副本，默认选择 `/dev/video0`（isx031-m3a），目标请求帧率为 60 fps。保留原工程的地图恢复、健康检查、频率/延迟记录及 `LIVE...` 后终端静默行为。

**当前为本地源码与接口适配，未部署到新 Jetson，未实机采集，也未验证 60 fps 或轨迹精度。** 原 `mono_imu_vio` 与 Jetson 环境不由本副本修改。

## 相机与标定状态

`params/camera_profile.json` 默认采用 video0 配置；`camera_video0.json` 与 `camera_video1.json` 保留为设备候选。1920×1536 UYVY、上下裁剪均为 0、请求 60 fps 来自设备树信息，尚非实测结论。用户选定 video0 不代表这些采集参数已经验证。

```bash
cd "$HOME/Documents/vio_ws/mono_vio_60"
python3 jetson/camera_config.py describe params/camera_profile.json
# 该命令只查看配置，不打开设备；已解压到 Jetson 的包可用 bash start.sh profile
```

`profile` 只读取配置，显示尺寸及标定绑定指纹，不打开相机或串口。当前时间域暂沿用旧机的 `cntvct` 假设，尚未在新驱动上验证；每次启动仍重新估计本次时钟映射。video1 仅为备选，不能把 video0 的配置或标定视为已适用另一相机。

已按用户确认，在 `params/orb_trial.yaml` 与 `params/timing.json` 暂用 **fit_05 全套相机内参、畸变、相机—IMU 外参、IMU 参数及 +16.8810565 ms 时间偏移**，状态为 `borrowed_fit05_trial_unvalidated`。启动器允许这套完整临时配置，并在 `LIVE...` 前提示参数来源；数值、尺寸、指纹及数据流检查仍保留。这不是新镜头或新安装位置的标定结果，不能用试跑轨迹验收精度。输入高度变化不用于推测内参缩放。之后更换三个活动文件的位置和字段见 [参数说明](params/README.md)。`VIO_SETTINGS` / `VIO_TIMING_FILE` / `VIO_CAMERA_PROFILE` 可选择包外文件。

IMU 采集保留原 FORSENSE/CP2102 协议、921600 波特率及原 500 Hz 配置；新机上的连接对象、协议和实际频率仍待验证。图像尺寸配置贯通原生预览、实时、录制、回放和导出；NEON 灰度提取按实际行跨度与裁剪配置处理，不默认删除第一行。

## 在 Mac 构建

```bash
cd "$HOME/Documents/vio_ws/mono_vio_60"
ORB_CONTAINER=orin-r365-dev bash build.sh
```

使用已有 Ubuntu 22.04 ARM64 Docker 容器，独立缓存为 `/build/mono-vio-60/`，输出 `dist/mono_vio_60.tar.gz`。核心源码清单校验通过才构建。若以后修改 `ORB_SLAM3/`，运行 `python3 tools/update_manifest.py` 更新当前源码清单；适配层修改无需更新核心清单。

目标宿主机为 Ubuntu 22.04 ARM64 / L4T R36.5。本副本使用容器现有 OpenCV 4.5.4 编译，与新机版本一致，并将所需 OpenCV 4.5、Boost serialization、GLU 运行库及许可证放入包内私有目录。原项目的 OpenCV 4.8 构建保持不动。部署后仍须用 `check.sh` 验证剩余系统图形依赖和完整动态链接；构建通过不等于传感器或标定已通过。

## 目录与保留行为

| 目录 | 用途 |
| --- | --- |
| `ORB_SLAM3/` | 继承的单目惯性核心，本次适配保持原样 |
| `adapter/` | 相机/IMU、时间映射、动态尺寸与算法调用 |
| `params/` | 默认/候选相机配置、暂用 fit_05 全套参数的活动配置及标定模板 |
| `jetson/` | 启动、依赖检查、状态、录制、回放与轨迹工具 |
| `docker/` | ARM64 编译、打包及动态链接检查 |
| `tests/` | 新配置回归及继承的核心/状态测试 |
| `provenance/` | 上游基线与源码变更记录 |

核心基于 ORB-SLAM3 提交 `4452a3c4ab75b1cde34e5505a36ec3f9edcdc4c4` 的修改版，仅保留单目＋IMU 输入。地图仍使用 `MONO_IMU_ATLAS_2`；加载成功与当前惯性恢复成功分别判断。独立未来数据复验、输出健康检查、参考图发布条件、频率/延迟记录和实时静默策略均沿用原实现。当前临时配置默认保存到 `maps/workspace_trial.osa`，与正式配置的 `maps/workspace_v2.osa` 分开；地图绑定配置及临时状态，保留恢复/保存功能。旧机地图不能因为格式相同就认定适用于新相机与新标定，试跑地图通过运行检查也不表示精度合格。

继承的 Shutdown 段错误问题尚未解决，本次适配不包含该修复。操作见 [Jetson 说明](jetson/README.md)，验证边界见 [测试说明](tests/README.md)。保留 [GPLv3 许可证](ORB_SLAM3/LICENSE) 与依赖许可证，发布修改版时须提供对应源码。
