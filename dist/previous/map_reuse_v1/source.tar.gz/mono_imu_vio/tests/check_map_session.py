#!/usr/bin/env python3
"""Map lifecycle tests: fingerprints, isolation, clean exit, and no replacement."""
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import tempfile
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("map_session", ROOT / "jetson/map_session.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def expect_error(fn, message):
    try:
        fn()
    except ValueError as error:
        assert message in str(error), str(error)
    else:
        raise AssertionError("Expected " + message)


with tempfile.TemporaryDirectory(prefix="map-session-test-") as tmp:
    root = Path(tmp).resolve()
    count = 0

    def run(mode="auto", reference=None):
        global count
        count += 1
        folder = root / "runs" / ("live_" + str(count))
        folder.mkdir(parents=True)
        shutil.copy2(ROOT / "params/orb_trial.yaml", folder / "settings.yaml")
        shutil.copy2(ROOT / "params/timing.json", folder / "timing.json")
        environment = {"VIO_MAP_MODE": mode, "VIO_MAP_FILE": str(reference or root / "maps/workspace.osa")}
        with patch.dict(os.environ, environment):
            plan = module.prepare(root, folder)
        session = folder / "session"
        session.mkdir()
        return folder, session, plan

    def core_saved(session, payload=b"guarded mature Atlas test fixture"):
        (session / "atlas.osa").write_bytes(payload)
        module.write_json(session / "map_save.json", {
            "status": "SAVED", "path": str(session / "atlas.osa"), "selected_map_id": 7, "keyframes": 40,
        })

    folder, session, plan = run()
    reference = Path(plan["reference"])
    assert plan["load"] == "" and not reference.exists()
    assert "MapReuse.Enabled: 1" in (folder / "settings.yaml").read_text()
    assert "MapReuse." not in (ROOT / "params/orb_trial.yaml").read_text()
    # First clean mature save becomes the reference with a timing/calibration guard.
    core_saved(session)
    assert module.finalize(session, 0)["status"] == "REFERENCE_PUBLISHED"
    initial_digest = module.digest(reference)
    module.validate_reference(reference, plan["calibration_sha256"])

    folder2, session2, plan2 = run()
    assert plan2["load"] == str(reference)
    core_saved(session2, b"second session Atlas must not overwrite reference")
    assert module.finalize(session2, 0)["status"] == "EXISTING_REFERENCE_PRESERVED"
    assert module.digest(reference) == initial_digest
    expect_error(lambda: run("new"), "MAP_E_EXISTS")

    # Display/extractor settings do not invalidate maps; physical calibration does.
    cfg = folder2 / "settings.yaml"
    before = module.calibration(cfg, folder2 / "timing.json")[0]
    cfg.write_text(cfg.read_text().replace("Viewer.ViewpointF: 500.0", "Viewer.ViewpointF: 600.0")
                   .replace("ORBextractor.nFeatures: 1500", "ORBextractor.nFeatures: 2000"))
    assert module.calibration(cfg, folder2 / "timing.json")[0] == before
    cfg.write_text(cfg.read_text().replace("Camera1.fx: 448.29128603612367", "Camera1.fx: 440"))
    changed = module.calibration(cfg, folder2 / "timing.json")[0]
    expect_error(lambda: module.validate_reference(reference, changed), "MAP_E_CALIBRATION")
    clock = folder2 / "timing.json"
    values = json.loads(clock.read_text())
    values["timeshift_cam_imu_rounded_ns"] += 1000
    values["timeshift_cam_imu_seconds"] += .000001
    clock.write_text(json.dumps(values))
    assert module.calibration(cfg, clock)[0] != changed

    # Failed/incomplete sessions can retain diagnostics but never publish.
    _, failed, failed_plan = run(reference=root / "maps/failed.osa")
    core_saved(failed)
    assert module.finalize(failed, 1)["status"] == "NOT_PUBLISHED"
    assert not Path(failed_plan["reference"]).exists()
    assert module.sidecar(failed / "atlas.osa").is_file()
    _, skipped, skipped_plan = run(reference=root / "maps/immature.osa")
    module.write_json(skipped / "map_save.json", {"status": "SKIPPED", "reason": "No mature map"})
    assert module.finalize(skipped, 0)["status"] == "NO_MATURE_MAP"
    assert not Path(skipped_plan["reference"]).exists()
    _, missing, _ = run(reference=root / "maps/missing.osa")
    expect_error(lambda: module.finalize(missing, 0), "MAP_E_SAVE")
    assert json.loads((missing / "map_session.json").read_text())["status"] == "ERROR"

    # Disabled sessions do not read even an invalid reference or create save paths.
    off_ref = root / "off/invalid.osa"
    off_ref.parent.mkdir()
    off_ref.write_bytes(b"invalid")
    _, off, off_plan = run("off", off_ref)
    assert off_plan["load"] == off_plan["save"] == ""
    assert module.finalize(off, 0)["status"] == "DISABLED"
    assert not (off / "map_save.json").exists()

    # Failure after map commit cannot remove or replace the valid committed pair.
    _, post_failure, post_plan = run(reference=root / "maps/post_failure.osa")
    core_saved(post_failure)
    original_fsync = os.fsync
    def fail_directory_sync(fd):
        if stat.S_ISDIR(os.fstat(fd).st_mode):
            raise OSError("simulated directory sync failure after commit")
        return original_fsync(fd)
    with patch.object(module.os, "fsync", side_effect=fail_directory_sync):
        try:
            module.finalize(post_failure, 0)
        except OSError as error:
            assert "after commit" in str(error)
        else:
            raise AssertionError("Expected simulated post-commit error")
    post_reference = Path(post_plan["reference"])
    module.validate_reference(post_reference, post_plan["calibration_sha256"])
    preserved_digest = module.digest(post_reference)
    _, next_session, _ = run(reference=post_reference)
    core_saved(next_session, b"different later map")
    assert module.finalize(next_session, 0)["status"] == "EXISTING_REFERENCE_PRESERVED"
    assert module.digest(post_reference) == preserved_digest

    # A stale half-published pair is rejected, never silently treated as fresh.
    orphan = root / "maps/orphan.osa"
    module.sidecar(orphan).write_text('{}')
    expect_error(lambda: run(reference=orphan), "MAP_E_MANIFEST")

    # Native legacy file keys must not coexist with generated lifecycle keys.
    for legacy in ("System.LoadAtlasFromFile", "System.SaveAtlasToFile"):
        legacy_run = root / legacy
        legacy_run.mkdir()
        text = (ROOT / "params/orb_trial.yaml").read_text()
        (legacy_run / "settings.yaml").write_text(text + '\n' + legacy + ': "old"\n')
        shutil.copy2(ROOT / "params/timing.json", legacy_run / "timing.json")
        with patch.dict(os.environ, {"VIO_MAP_MODE": "off"}):
            expect_error(lambda: module.prepare(root, legacy_run), "MAP_E_CONFIG")
    # Corruption and absent manifests fail before native tracking starts.
    reference.write_bytes(b"changed")
    expect_error(lambda: run(), "MAP_E_CHECKSUM")
    module.sidecar(reference).unlink()
    expect_error(lambda: run(), "MAP_E_MANIFEST")

print("MAP_SESSION_TEST_PASS")
