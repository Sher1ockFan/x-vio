# mono_imu_vio

单目惯性定位、旧地图重定位及输入频率/延迟测量包。部署到 `~/Documents/mono_imu_vio`，不覆盖现有 `vio_nx` 或 `name_test`。实时测试继续使用 B 口、原标定参数及两个原生窗口，`LIVE...` 后终端静默。

适用于 Jetson Orin NX 的仅支持单目＋IMU 的 ORB-SLAM3 修改版。Mac 端在 ARM64 Docker 中编译，Jetson 解压后在宿主机运行。核心精简自上游提交 `4452a3c4ab75b1cde34e5505a36ec3f9edcdc4c4`。窗口是原生地图与当前图像。

原分辨率配置来自在 C 通道复核过的 `fit_05` 标定。相机采集 1920×1441 UYVY，跳过首行元数据后得到 1920×1440 灰度图，ORB 内部缩放到 960×720。IMU 为 500 Hz，实时采集在相机时间映射后应用一次 **+16,881,057 ns**，回放沿用录制时已经同步的时间戳。原分辨率配置在 `params/orb_trial.yaml` 和 `params/timing.json`。

本版灰度提取使用 ARM NEON，每次从 UYVY 中提取 16 个原始 Y 值；相机采集程序使用 `-O3 -march=armv8-a` 编译。仍跳过首行元数据、输出 1920×1440 灰度图，再由 ORB 内部缩放到 960×720。相机像素、时间戳与标定参数不变；核心只保留单目惯性输入路径。

优化前后应在 Jetson 上用相近场景和运行负载对比 `performance.txt` 中的灰度提取中位数/P95、采集帧率和图像到跟踪返回延迟。Docker 验证像素一致和程序可运行，不将 Mac 容器耗时当作 Jetson 提速结果。

## 安装与检查

把 `mono_imu_vio.tar.gz` 上传到 Jetson 用户家目录，在 Jetson 桌面终端执行。

```bash
mkdir -p "$HOME/Documents"
tar -xzf "$HOME/mono_imu_vio.tar.gz" -C "$HOME/Documents"
kit="$HOME/Documents/mono_imu_vio"
bash "$kit/check.sh"
```

看到 `ORB_HUB_CHECK_OK` 后可以启动。包内带词典和项目运行库。宿主机需保留 Ubuntu 22.04 ARM64、Jetson Linux R36.5.0、NVIDIA OpenCV 4.8 `.so.408` 运行库、图形运行库和 `python3-numpy`。原生图形窗口使用桌面 X11 会话。

实时入口使用 `/dev/gmsl/B`。实时与录制入口统一使用同一个 B 通道。IMU 使用原 CP2102 `/dev/serial/by-id` 设备链接和 921600 波特率。账号需要能读写相机和读取串口。若缺少权限，用 `ls -lL /dev/gmsl/B /dev/serial/by-id/*` 查看设备和用户组，确认后加入对应的 `video` 或 `dialout` 组，再重新登录。`--devices` 检查 B 通道和 IMU 的设备节点及权限。

## 实时和录制

关闭其他占用相机或 IMU 串口的程序。实时预览默认将日志放入 `$kit/runs/live_*`。录制时每次指定新的目录。

```bash
# B 口原分辨率实时查看。0 表示运行到按 Ctrl+C
bash "$kit/start.sh" live 0

# B 口录制原始图像和 IMU，任选其一
take="$kit/runs/take_01"
bash "$kit/start.sh" record "$take"
# 或者另用一个新目录，同时开启两个原生预览窗口
bash "$kit/start.sh" record-view "$kit/runs/take_02"
```

录制时按一次 Ctrl+C，等终端返回。`capture.json` 中的 `COMPLETE` 表示录制封存完成。按 30 fps，每分钟原始录制约占 5 GB，离线转换还会另存 PNG 图像。实时预览与正式录制的用途不同，评估逐帧轨迹时使用封存数据回放。

实时入口校验 B 通道的驱动卡名 `pnd_gmsl_mc 10-003b` 和采集总线 `platform:tegra-capture-vi:0`。实时程序打开 IMU 串口后先读过前 0.5 秒的启动数据，随后校验连续数据并采集约 10 秒估计时钟映射。B 通道暂用 C 通道标定的时间偏移，时延需实机复验。

实时入口打印 `LIVE: move the rig with both translation and rotation in a textured scene.` 后不再输出运行进度、报错详情或收尾提示。原生两个窗口仍运行；按一次 Ctrl+C 后等待终端返回。启动失败仅显示错误码 `VIO_E_STARTUP`，详情保存在 `runs/startup_*.log`，已创建会话时保存在 `session/console.log`。运行中异常保留非零退出状态，详情查 `session/live.json` 和 `session/console.log`。终端自身显示的 `^C` 或命令提示符不属于程序输出。

`session/console.log` 保留原有进度、`sent` 和 `superseded`，后二者分别为完整写入 ORB 管道的帧数和被新帧替代的帧数；完整写入不等于 ORB 已经完成跟踪。`session/camera.log` 继续保留采集日志。

## 旧地图优先与保存加载

`live` 默认启用旧地图优先重定位。第一次没有参考地图时正常建立地图；在光照充足、有稳定纹理的工作区做平缓平移和转动，使 IMU 初始化和地图优化完成。按一次 Ctrl+C，等命令返回，原生线程退出后才会检查保存结果。只有核心认为成熟、保存成功且本次采集正常结束的地图，才会首次发布为 `$kit/maps/workspace.osa`；配套 `.osa.meta.json` 记录标定、时间基准和文件校验。

请用 Ctrl+C 正常结束采集。直接关闭原生窗口会结束跟踪并收尾保存，但实时采集将记为中止，因此不会首次发布新的参考地图。

```bash
kit="$HOME/Documents/mono_imu_vio"
# 第一次建立参考地图；以后同一命令会自动加载它
DISPLAY=:0 bash "$kit/start.sh" live 0

# 退出后查看保存/发布结果，终端不会自动打印这些内容
d=$(ls -td "$kit"/runs/live_*/session | head -n 1)
cat "$d/map_save.json"
cat "$d/map_session.json"
```

`map_save.json` 的 `SAVED` 表示本次 `session/atlas.osa` 写入成功；`SKIPPED` 表示没有达到保存条件。当前成熟条件是 IMU 已初始化、完成第二阶段惯性优化（BA2）、至少 12 个关键帧和 50 个地图点；它是复用门槛，不是精度证书。`map_session.json` 的 `REFERENCE_PUBLISHED` 表示已首次发布参考地图，`EXISTING_REFERENCE_PRESERVED` 表示保留原有参考地图，本次结果仍单独保存在会话中。`NO_MATURE_MAP` 表示需要继续完成可靠初始化/建图；`NOT_PUBLISHED` 表示采集未正常结束。加载或保存错误写在 `orb.log`、`console.log` 和相应 JSON 中。启动失败仍只在终端显示 `VIO_E_STARTUP`。

已有参考地图永不自动覆盖。加载时校验地图内容、词典兼容性、相机/IMU 标定及 ORB 金字塔层数/尺度；辅助清单额外核对相机—IMU 时间偏移及时间基准。修改内外参、图像尺寸、同步参数或金字塔配置后，应新建参考地图，不能删除清单来绕过检查。相机与 IMU 的安装关系、镜头或图像裁切发生变化时也应先重新标定。搬运地图时必须把 `.osa` 与 `.osa.meta.json` 一起复制；`.lock` 是文件操作锁，不是地图数据。

```bash
# 为另一组场景/标定建立新地图；new 拒绝覆盖已有目标
VIO_MAP_MODE=new VIO_MAP_FILE="$kit/maps/desk_02.osa" \
  DISPLAY=:0 bash "$kit/start.sh" live 0

# 以后加载这一份地图
VIO_MAP_MODE=auto VIO_MAP_FILE="$kit/maps/desk_02.osa" \
  DISPLAY=:0 bash "$kit/start.sh" live 0

# 做关闭地图复用的对照运行；不加载、不保存、不发布参考地图
VIO_MAP_MODE=off DISPLAY=:0 bash "$kit/start.sh" live 0
```

重定位需要重新看见旧地图中足够稳定且分布合理的特征；遮挡期间 IMU 不能消除位置漂移。旧地图给出视觉定位参考，不能直接恢复关机前或失跟前的速度与偏置。程序在重新取得视觉约束后使用新 IMU 数据恢复惯性状态；此阶段应保持画面清晰、动作平缓。已经找到成熟旧图时，静止也可能恢复；首次新建图仍需平移与转动激励。恢复通过之前，位姿日志保持 `valid=0`，不会把旧地图的“IMU 已初始化”标志当成当前状态已恢复。

恢复默认尝试约 12 秒；未通过时保留旧地图，给新地图约 5 秒初始化机会。如果仍未初始化，会再次尝试旧地图。恢复和重新初始化期间当前图像继续刷新；恢复失败不通过强行沿用旧位姿来伪造连续轨迹。

| `phase` | 含义 |
| --- | --- |
| `MAPPING` | 新地图的视觉或惯性初始化尚未就绪 |
| `SEARCHING` | 正在查找并验证旧地图位置，或等待后台线程暂停 |
| `ALIGNING_IMU` | 视觉已找到旧地图，正在估计当前速度与 IMU 零偏 |
| `TRACKING` | 本帧正常跟踪且当前惯性状态就绪 |

`session/recovery_events.csv` 记录阶段、地图 ID、匹配内点数、视觉/惯性就绪和原因的变化；`session/poses.csv` 逐帧记录相机在当前地图坐标系中的 `T_wc`，平移单位为米，四元数顺序为 `qx,qy,qz,qw`。只有 `valid=1` 的行才包含可用惯性位姿，其他行使用 `nan`。这些是跟踪当时的估计，不是回环后统一优化的最终轨迹，也不能证明绝对精度。绘图时按 `map_id` 和有效段分段，不跨失跟间隔或新地图原点连线。

`record`、`record-view`、`replay` 和 `trajectory` 保持独立的新会话流程，不读取实时参考地图，也不会因 `VIO_MAP_*` 环境变量改写已封存录制的参数。频率/延迟测试持续保留在实时入口。

## 输入频率与延迟测试

实时入口自动开启计时，结束后静默生成 `session/performance.txt`（中文报告）和 `session/performance.json`（结构化数据）。测试日志保留在适配层；单目惯性的参数、采集格式和选帧策略保持原样。核心接口和源码已精简为单目＋IMU。

```bash
kit="$HOME/Documents/mono_imu_vio"
# 此次测量运行 60 秒；词典加载、约 10 秒 IMU 时钟拟合另计
DISPLAY=:0 bash "$kit/start.sh" live 60
# 也可使用 live 0，自己按一次 Ctrl+C 收尾
```

前一段在有纹理、光照充足的场景做平缓平移和转动，让惯性初始化有足够运动；初始化后按正常使用方式继续。不要只原地静止等待初始化。运行结束后再执行：

```bash
d=$(ls -td "$kit"/runs/live_*/session | head -n 1)
cat "$d/performance.txt"
```

报告区分相机驱动时间戳频率、主机收图速度、实际入 ORB 的图像/IMU 频率和跟踪调用完成频率，给出各环节中位、P95、最大耗时。P95 表示 95% 的有效测量值不超过它。成功且 IMU 就绪的帧单独统计；没有此类帧会明确标为不可评估。判断数据质量需同时看运行状态和失跟情况，不能只看速度。

新增文件用途：

| 文件 | 记录内容 |
| --- | --- |
| `camera_timing.csv` | 驱动时间戳、映射后的 RAW 时间、取缓冲区、灰度提取和管道写入时间 |
| `imu_timing.csv` | 串口每次读取中有效 IMU 样本数、设备计时器范围、主机读取时间，含启动时钟拟合阶段 |
| `camera_read.csv` | Python 完整读到图像的时间 |
| `input_timing.csv` | 选帧、IMU 配齐、整包送入算法的时间和样本数 |
| `tracking_timing.csv` | ORB 适配器完整接包、TrackMonocular 开始/返回、跟踪状态和 IMU 就绪代理 |
| `performance.txt/json` | 汇总结果；退出后由 `performance.py` 读取上述记录生成 |
| `console.log` | 启动及运行详情，包括被终端隐藏的输出 |
| `poses.csv` | 逐帧相机位姿、有效性、地图 ID 和恢复阶段；无效帧不输出数值位姿 |
| `recovery_events.csv` | 重定位和惯性恢复阶段变化、地图 ID、内点数及原因 |
| `map_save.json` / `map_session.json` | 核心保存结果与参考地图发布结果 |

使用 `CLOCK_MONOTONIC_RAW` 统一主机计时。相机源时间先映射到 RAW，再应用原有 +16.881057 ms 配置偏移。此偏移不是处理耗时，也不在本次测试中重新标定。驱动事件到 TrackMonocular 返回是软件可测的图像年龄；尚未验证驱动时间戳与真实曝光时刻的关系，因此不把它称为物理曝光到输出延迟。窗口呈现、异步建图和回环结束时间不包含在 TrackMonocular 调用耗时内。最新 IMU 样本年龄也受原有时钟映射影响，不代表已校准的串口传输延迟。

`imu_initialized_proxy` 在 `tracking_state==2` 且本帧惯性状态就绪时为真。启用地图复用时，它读取恢复状态接口：加载旧图或失跟后的视觉重定位成功，还需要新惯性状态恢复通过才会为真。关闭地图复用时保持原先的保守判据：当前帧有效地图点属于同一张已初始化地图；没有地图点、跨图混合或失跟时为假。不调用初始化前可能尚不可用的 `GetTimeFromIMUInit()` 调试接口；该代理不用于证明轨迹精度。IMU 按图像分批输入，不会因此每秒输出 500 个位姿。CSV 会有少量计时和磁盘写入开销，报告反映本测试版本的实际表现。

需要重新生成报告时，可执行 `python3 "$kit/performance.py" "$d"`；该命令也保持静默，不调用传感器或重新运行 SLAM。

## 回放和轨迹导出

```bash
# 回放录制，显示两个原生窗口
bash "$kit/start.sh" replay "$take"

# 单目惯性 EuRoC 示例离线求轨迹，路径见终端输出
bash "$kit/start.sh" trajectory "$take"
```

`trajectory` 生成 `CameraTrajectory.txt` 和 `KeyFrameTrajectory.txt`。用浏览器打开包内 `trajectory_view.html` 可回看前者。原生单目惯性轨迹输出 IMU 主体位姿，返回误差工具使用外参转换到相机坐标系。

## A→B→A 检查

在第一个终端启动新录制。

```bash
kit="$HOME/Documents/mono_imu_vio"
take="$kit/runs/take_03"
bash "$kit/start.sh" record "$take"
```

看到录制目录的 `record.log` 出现 `Recorded` 后，先对着有纹理的场景做约 20 秒平移和转动。保持录制运行，在第二个终端执行下列命令，按提示记录固定姿态 A、B 和返回 A，每段静止 3 秒。

```bash
kit="$HOME/Documents/mono_imu_vio"
take="$kit/runs/take_03"
bash "$kit/start.sh" mark "$take"
```

标记完成后再录几秒，在第一个终端按 Ctrl+C 封存。用 `bash "$kit/start.sh" trajectory "$take"` 回放，成功检查时可查看 `accuracy.json` 里的 A→B 位移、返回 A 偏差和静止段抖动。返回偏差衡量重复性，绝对误差需要独立实测参考。

`source/ORB_SLAM3` 是随包提供的精简修改版核心源码，`source/adapter` 是项目采集和运行适配源码。启动使用包内已编译程序。
